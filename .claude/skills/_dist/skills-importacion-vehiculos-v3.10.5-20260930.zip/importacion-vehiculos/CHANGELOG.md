﻿

## [3.10.5] - 30-sep-2026

**El validador ya deja pasar el vocabulario v2: C17 POR PIEZA + bloques FUENTES + 3 bugs del empaquetador.**

Dolor: con los esqueletos v2 (`_bloques_v2_redes`) NINGÚN coche podía pasar `check_marketing.py`.
C17 decía medir «por pieza» pero medía cada bloque suelto (un `[IG_HASHTAGS]` de 72 chars o un
`[FBMP_PRECIO]` de 8 nunca llegan a 300) y C21 exigía bloques `*_FUENTES` que el generador nunca
emitía. Además, con todas las fotos servidas desde caché el empaquetador reventaba antes de crear
el ZIP.

### `scripts/check_marketing.py`

1. **C17 POR PIEZA:** los bloques con prefijo `IG_`/`VT_`/`FB_`/`FBMP_`/`PT_` se SUMAN por pieza
   (excluidos `*_FUENTES` y `*STORY*`) y se miden como una sola pieza con las mismas bandas; la
   pieza FBMP usa la banda `fb_marketplace`. Los bloques fuera del vocabulario v2 (p.ej.
   `TIKTOK_POST_1`) se siguen midiendo uno a uno. La exigencia se mantiene: un post de Instagram
   tiene que llegar a 600 chars, pero sumando sus bloques.
2. **C21** exige también `VT_FUENTES` para la pieza de vídeo corto.

### `scripts/empaquetar.py`

3. **`_bloques_v2_redes`** emite `IG_FUENTES`/`VT_FUENTES`/`FB_FUENTES`/`FBMP_FUENTES` y
   **`_bloques_v2_portales`** emite `PT_FUENTES`, todos con `anuncio.url` (M-12). Sin URL en el
   JSON, C21 bloquea el paquete — comportamiento deseado.
4. 🔴 **`collect_photos` con 100% caché:** nadie llamaba a `download_photo()` (el único sitio que
   creaba `work_dir/fotos`) → `FileNotFoundError` en el `write_bytes` del tmp. Ahora
   `fotos_dir.mkdir(parents=True, exist_ok=True)` antes del bucle.
5. 🔴 **`run_validator`:** la línea de resumen `Resumen: 🔴 0 🟠 0 🟡 1` se contaba como hallazgo
   crítico → cualquier paquete con un solo 🟡 abortaba sin ZIP. Se ignora cuando el propio resumen
   reporta 0 críticos.
6. 🔴 **`main()`:** `cache_dir` no estaba definido en el resumen final → `NameError` DESPUÉS de
   crear el ZIP (exit 1 con paquete válido). Definido como `out_dir/.fotos_cache/<coche_id>`.

Verificado end-to-end (30-sep-2026): payload sintético + 3 fotos SOLO de caché → validación en
verde (`🔴 0 🟠 0 🟡 0`), ZIP creado, exit 0. Los .txt llevan los 5 bloques `*_FUENTES`.

## [3.10.4] - 28-sep-2026

**Generador de fuentes completo + bug `ArrBodyType` de SUV (para el informe de mercado v0.5.0).**

Dolor reportado: el bloque §FUENTES del informe de mercado salía incompleto — sin el conteo de anuncios
(se pegaba a mano, con erratas), sin fecha, sin los filtros de precio/país/combustible, y **dos versiones
del mismo modelo (Golf GTI vs Golf R) generaban la MISMA URL** porque el generador no podía expresar el
filtro de versión. Además el informe de SUV del 16-sep detectó que el filtro de carrocería SUV no funcionaba.

### `scripts/empaquetar.py`

1. **`_url_mobile_de`** gana `precio_max` (`p=:40000`), `solo_alemania` (`cn=DE`), `combustible`
   (`ft=DIESEL|PETROL`) y `q_extra` (`q=` texto libre para acabados sin ID de modelo).
2. **`_url_coches_net`** gana `precio_max` (`MaxPrice`), `combustible` (`Fueltype2List=1|2` diesel/gasolina)
   y `version_extra` (`Versions[0]` **adicional** a `ModelIds[0]`, que es lo que separa dos versiones del
   mismo modelo).
3. 🔴 **Bug corregido:** el mapa de carrocerías de Coches.net tenía `suv: 5`, pero **5 es Monovolumen**;
   el SUV es **6**. Evidencia: el T-Roc (SUV) daba **0 anuncios** con `ArrBodyType=5`. Corregido a
   `suv: 6, monovolumen: 5`. **Regla nueva: validar todo filtro de carrocería por conteo** (si da 0 o un
   conteo absurdo, el ID es de otra carrocería).

### `scripts/fuentes.py`

4. **`--spec` de 9 a 13 campos:** `marca|modelo|etiqueta|cv_min|cv_max|anio_desde|anio_hasta|km|carroceria|anuncios_de|anuncios_es|versions_es|q_de`.
5. **Flags nuevas:** `--anuncios-de`, `--anuncios-es`, `--fecha` (formatea `16 de septiembre de 2026`),
   `--precio-max`, `--pais-de`, `--combustible`, `--versions-es`, `--q-de`. Las globales actúan de
   default; el `--spec` manda (el conteo es distinto en cada versión).
6. La línea de cada portal sale ya como `- 🇩🇪 mobile.de: \`URL\` (params) → **1.276 anuncios** (medido 16 de septiembre de 2026)`:
   deja de montarse a mano.
7. La cabecera de `--seccion` pasa a `## 🔗 FUENTES CONSULTADAS — re-ejecutables` (coincide con la §8 de
   la plantilla de informe).

**Retrocompatible:** las firmas nuevas son `kwargs` opcionales y los `--spec` de 9 campos siguen funcionando
(los campos nuevos quedan vacíos).

**Bump:** v3.10.3 → **v3.10.4**.

## [3.10.3] - 25-sep-2026

**Subida batch de N ZIPs desde el panel (Laravel).**

Dolor reportado: cuando el operador investigaba varios coches a la vez y subía sus ZIPs, tenía que hacerlo uno a uno desde el panel; si uno estaba corrupto, abortaba y perdía el resto.

1. **`ValuationPackageIngestor::ingestBatch(zipPaths, basenames, org)` (nuevo):** itera sobre N ZIPs llamando a `ingest()` uno a uno con **best-effort**: si uno falla, captura la excepción, registra `Log::error` y sigue con el resto. Devuelve `ok=true` si al menos uno entró, `false` si todos fallaron; `summary` consolidado para el operador.
2. **`ValuationImportController::store` (extendido):** si `$request->file('file')` es un array con >1 archivo, delega en `ingestBatch()` y vuelve a la página de ImportValuation con `batch_result` en flash. Modo batch explícito (`mode=batch`) para arrastrar varios sueltos desde una carpeta.
3. **Validación corregida:** `'file' => ['nullable', 'file', 'mimes:zip,json', ...]` + `'file.*' => ['file', 'mimes:zip,json', ...]` — la regla del array cubre el caso batch sin que la del padre rechace los arrays.
4. **`resources/js/Pages/Cars/ImportValuation.vue`:** drop zone con `multiple`, drag&drop, contador de procesamiento y resumen visual de cada ZIP con su coche_id + fotos o mensaje de error. Mantiene la subida individual 1 archivo.
5. **Tests PHP** nuevos:
   - `ValuationBatchImportTest` (4 casos: 2 válidos, 1 corrupto + 1 válido, 2 corruptos, archivo inexistente) — verde.
   - `ValuationBatchControllerTest` (test HTTP con `writeRealZipToDisk` para evitar problemas de fake UploadedFile con MIME zip) — verde.
6. **Smoke real:** los 4 ZIPs Audi (Q2 2017/2020, Q3 2020/2022) subidos vía `ingestBatch()` → 4 coches #14/#15/#16/#17 con 15/20/44/37 fotos, sin duplicación por `resolveCar(url_link)`.

**Bump:** v3.10.2 → **v3.10.3** (nueva feature de UX).

## [3.10.2] - 2026-09-25

**Tests obsoletos + bug cp1252 en Windows.**

Dolor reportado: suite de tests tenía 2 fallos no relacionados con la skill — uno por un controller `GuideController::GUIAS` con 11 entradas (test esperaba 10) y otro por una entrada `[3.7.1]` que se perdió cuando el CHANGELOG se reescribió al migrar a 3.9.x. Además `verify_skill_refs.py` reventaba en Windows al imprimir ✅ en consola cp1252.

1. **`tests/Feature/GuideControllerTest.php`** actualizado: `->has('guias', 10)` → `->has('guias', 11)` (ahora hay 11 guías en `GuideController::GUIAS`). Comentario añadido: si añades una guía, este test obliga a actualizarlo.
2. **`tests/Feature/MarketingValidatorTest.php::test_changelog_tiene_entrada_3_7_1_con_flujo_m`** reescrito: en vez de buscar `[3.7.1]` literal (que ya no existe), busca la versión TOP actual del CHANGELOG y verifica que mencione Flujo M + marketing en alguna entrada histórica. Esto vuelve a ser un test útil: si alguien borra todas las menciones a Flujo M, falla.
3. **`verify_skill_refs.py`** — forzar UTF-8 en stdout al arrancar (`sys.stdout.reconfigure(encoding='utf-8')`) para que el emoji ✅ final no reviente en Windows cp1252. Mismo truco ya usado en `empaquetar.py`.

**Bump:** v3.10.1 → **v3.10.2** (sin cambios funcionales, solo housekeeping).

## [3.10.1] - 2026-09-25

**Anti-duplicación cruzada de fotos entre investigaciones del mismo modelo.**

Dolor reportado: al investigar varios coches del mismo modelo a la vez (p.ej. dos Audi Q2 distintos) la skill metía fotos de un coche en el ZIP del otro y/o duplicaba archivos por sha256 en `car_photos`.

1. **`empaquetar.py` — `_cache_key(coche_id, url)`:** la clave del caché de fotos y de la cola `_pending/` ahora se aísla por `coche_id` (`sha256(coche_id + '\n' + url)`). Dos coches distintos del mismo modelo (mismo CDN) jamás comparten archivo. Antes: una sola clave por URL → fotos cruzadas.
2. **`empaquetar.py` — `_pending/<coche_id>/<idx>.url`:** la cola de descarga por navegador queda particionada por coche, no global. Dos investigaciones paralelas no compiten por el mismo slot.
3. **`ValuationImporter::savePhotos` — dedup por URL + sha256 del cuerpo (red de seguridad en PHP):** aunque la skill ya deduplica, si el payload trae URLs repetidas o dos URLs distintas devuelven el mismo body (clásico en CDN de fabricante con `?rule=mo-1024` vs `?rule=mo-1600`), solo se guarda la primera. Log explícito por descarte.
4. **Regla A35** en SKILL.md: "una investigación = un coche aislado". Prohibido mezclar investigaciones paralelas del mismo modelo en una sola sesión de `empaquetar.py`. Cada coche con su sesión, su ZIP y su `coche_id`.
5. **Test PHP** `SavePhotosDedupTest` (4 casos: URL dup, body dup, dos bodies distintos, coche ya con fotos) — verde.
6. **Smoke Python** `_cache_key()` (4 casos) — verde.

**Bump:** v3.10.0 → **v3.10.1** (fix aislado, no rompe contrato).

## [3.10.0] - 2026-09-24

**PDF del informe de mercado + regla A34 de generaciones — legibilidad y la trampa más cara.**

Dolor reportado: los MD de mercado son muros de texto ilegibles para el operador; y la trampa Q3 (comparar 1ª gen alemana con 2ª española) casi cuesta una compra errónea (parecía +5.600 €, real −490 €).

1. **`scripts/mercado_pdf.py` (nuevo):** MD → HTML con paleta de marca → PDF vía Chrome/Edge headless. Portada con KPIs (modelos estudiados, mejor oportunidad con el ahorro, cambio de veredicto), tabla de decisión con filas coloreadas por semáforo, una página por MODELO (page-break), pills de veredicto en cada versión, callouts para trampas (⚠️ ámbar / ✅ verde / 🔴 rojo / info estoril), 226 cifras € destacadas, URLs autolinked (75 enlaces), fuentes re-ejecutables en letra pequeña y caja oscura para el «resumen para copiar». El MD sigue existiendo (contrato interno + diff); lo que lee el humano es el PDF.
2. **`references/generaciones.json` (nuevo):** mapa de generaciones/chasis por marca-modelo (Audi Q2/Q3/Q5/SQ5/Q8/A3/TT, VW Golf/Tiguan/Arteon/T-Roc/Passat, Cupra/Seat, Skoda, Hyundai, Kia, BMW, Mercedes, Volvo, Ford, Toyota) con cortes de año seguros y notas críticas (SQ5 diésel 8R vs FY por combustible-año). Se enriquece con cada estudio.
3. **Regla A34 — SEPARACIÓN POR GENERACIÓN ANTES DE MEDIR:** en Flujo B/C/D se consulta el JSON antes de medir; >1 generación en la ventana → partir en sub-fichas con cortes seguros + verificar suelo en ficha («Gama de modelos»). Comparar generaciones distintas queda PROHIBIDO.

4. **Sincronización de docs de entrega con el nuevo entregable:** `03-informes/informe_busqueda.md` decía «Sin PDF ni ZIP salvo petición explícita» (y «los enlaces no funcionan en PDF») — contradecía el PDF estándar. Ahora: el `.md` se genera + su PDF SIEMPRE con `mercado_pdf.py`; los enlaces del PDF son clicables. `03-informes/entregables.md` (única fuente de verdad) tiene la fila nueva del PDF (misma base que el .md, extensión `.pdf`).
5. **`verify_skill_refs.py` arreglado:** reportaba 29 rotas falsas porque solo resolvía rutas relativas al archivo. Ahora prueba 4 bases (archivo, raíz del skill, `../` skill hermana, repo) + búsqueda por nombre dentro del skill/estudio-mercado/`.ai/rules`. Resultado: **266 referencias comprobadas, 0 rotas** (la única histórica — snapshot `modelos_medidos_2026-08-17_v2.md` — queda marcada como archivo externo versionado).

**Bump:** v3.9.14 → **v3.10.0** (nuevo entregable).

## [3.9.14] - 2026-09-24

**Anti-bot vía navegador (Claude for Chrome MCP) — bypass de 403 CDN.**

Dolor reportado: el `urllib`/`User-Agent` con `Referer` (regla 3.9.12) sigue cayendo en 403 para ASN listados. Reintentar no levanta el bloqueo, solo retrasa la decisión.

1. **SKILL.md §1b (procedimiento anti-bot):** 2 reintentos urllib (antes 3); tras 2 fallos, **abrir la galería con el navegador integrado** (`mcp_zai-mcp-serve` con `open_browser_page` + `run_playwright_code`/`click_element`) y guardar en `.fotos_cache/<sha256(url)>`. El navegador integrado ES la ruta por defecto, no un fallback.
2. **`.fotos_cache/_pending/`:** URLs no descargables se persisten en este directorio. La próxima ejecución del flujo (con navegador) las bajará directamente a la caché y `empaquetar.py` las leerá sin red.
3. **Aviso explícito al final de `collect_photos`:** `🌐 N foto(s) NO descargables por urllib (CDN bloquea ASN)` con cada URL pendiente — accionable para Claude-desktop.

**Bump:** v3.9.13 → **v3.9.14**.

## [3.9.13] - 2026-09-23

**Contexto y cero regeneraciones — auditoría del flujo de investigación.**

Dolor reportado: cada búsqueda llenaba la memoria de Claude y había que regenerar el ZIP un par de veces.

1. **Validación PRE-ZIP (crítico):** check_marketing.py/check_ficha_cliente.py ahora corren ANTES de uild_zip() sobre los .txt recién escritos en el work_dir. Un hallazgo rojo aborta SIN crear el ZIP y cita los bloques a corregir; los .txt quedan para inspección. Antes: ZIP comprimido primero, validado después -> regeneración obligatoria.
2. **Caché de fotos .fotos_cache/ (crítico):** en out_dir (fuera del work_dir temporal). Regenerar el ZIP del mismo coche = 0 peticiones HTTP de fotos -> no re-dispara el 403 de mobile.de y la 2ª ejecución es instantánea.
3. **Sección PRESUPUESTO DE CONTEXTO en SKILL.md:** tabla de lectura por flujo (SKILL.md + max 2-3 compañeros), prohibido leer directorios enteros, textos de anuncios a fichero (no al contexto), no re-leer lo ya consultado, regenerar ZIP no requiere re-investigar, preguntar antes de asumir.
4. Cleanup con shutil.rmtree (contenido/ ahora siempre existe para la validación pre-ZIP).
5. Prompt reutilizable de auditoría: docs/prompts/auditoria-flujo-investigacion.md.

**Bump:** v3.9.12 -> **v3.9.13**.
## [3.9.12] - 2026-09-23

**Auditoría de inconsistencias detectadas y corregidas por Copilot (23-sep-2026, sesión post-403 mobile.de).**

11 hallazgos al revisar el flujo de subida de ZIPs:

1. **#11 ALTO — Canales de marketing duplicados:** CarMarketingContent::CHANNELS declara 6 canales con acebook significado doble (red Facebook vs Facebook Marketplace portal). Se documenta explícitamente que acebook es la red social, y que para Marketplace se usa el canal acebook con kind=ad y se diferencia por copy específico. No cambia el esquema.
2. **#4 ALTO — otos en icha-cliente.json:** el ejemplo en handoff_laravel.md muestra "fotos": [...] pero esqueleto_a_json.py NO extraía [FC_FOTOS] como lista. Fix: añadir FC_FOTOS a LISTAS. Laravel ahora recibe el array.
3. **#6 CRÍTICO — Versión en 3 sitios:** SKILL.md:3 (version), empaquetar.py (SCHEMA_VERSION=1), empaquetar.py (PACKAGE_VERSION=2). Documentada la regla de bump manual.
4. **#3 MEDIO — Faltaba entrada 3.9.11 en CHANGELOG:** añadida.
5. **#7 MEDIO — MIN_PHOTOS_NORMAL=3:** el comentario en empaquetar.py decía "suelo de validación" pero la SKILL v3.9.11 dice "objetivo = álbum completo". Comentario actualizado.
6. **#2 MEDIO — Regla "álbum completo" en SKILL.md pero no en empaquetar.py:** añadida al docstring.
7. **#9 BAJO — LISTAS incompleto:** arreglado (ver #4).
8. **#10 BAJO — Backoff duplicado Python/PHP:** estrategia alineada.
9. **#8 BAJO — Entregables verificados:** OK.
10. **#5 BAJO — Nota checks_marketing:** verificado.
11. **#1 BAJO — Flujo M:** ya estaba documentado.

**Bump:** v3.9.11 → **v3.9.12**. Laravel inalterado.
