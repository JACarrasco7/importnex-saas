# Guía de búsqueda manual — Renault

**Fecha:** 2026-10-06 · **Fuente de datos:** datos_mercado.json (`actualizado: 2026-08-23 (Golf R: cobertura DE completa 7/7, veredicto verde conf 4) | 2026-08-24 (R cerrado a 'buscado' por consistencia con GTI/TCR/Clubsport del estudio; falta generar informe_modelo_golf-r-mk75.md para dossier entregable) | 2026-09-13 (refresco parcial de OFERTA en las 9 showstoppers, medido en vivo; medianas intactas del estudio)`) · **IDs mobile.de verificados:** 2026-09-13

> Guía de USUARIO: para buscar a mano en coches.net y mobile.de sin equivocarte de generación ni de motor. Los precios y huecos salen TAL CUAL del mapa; la tabla de motores/CV es referencia del fabricante para IDENTIFICAR, no una medición de mercado.

## Los modelos de esta marca (de un vistazo)

| Modelo | Qué es (generación) | Años | CV | Veredicto | Hueco neto |
|---|---|---|---|---|---|
| Renault Megane gasolina | Renault Megane IV (2016+) | 2016+ | — | 🟡 amarillo | -7.4% |

## Chuleta: dónde está cada filtro

| Filtro | coches.net | mobile.de |
|---|---|---|
| Marca y modelo | Selectores «Marca» y «Modelo» arriba del buscador | «Marke» y «Modell» (o añade `ms=<marca>;<modelo>` a la URL) |
| Año | Slider «Año» → desde | «Erstzulassung ab» |
| Potencia | Slider «Potencia» → desde (CV) | «Leistung ab» (PS) |
| Precio | Sliders «Precio» → desde / hasta | «Preis ab / bis» |
| Versión/motor | Campo «Versión» (texto libre) | Palabra clave en `q=` |
| Combustible | «Combustible» | «Kraftstoff» |


## Renault Megane gasolina — Renault Megane IV (2016+) · 🟡 amarillo

Categoría: **gemas_economicas** · Segmento: **compacto** · Cliente: **diario_eficiencia** · Precio: banda **8-14k**

**Motores para identificar (referencia fabricante, no medición):**

| Motor | CV | Años |
|---|---|---|
| TCe 100/115 | 100-115 CV | 2016+ |
| TCe 130/140 | 130-140 CV | 2016+ |
| TCe 160 EDC | 160 CV | 2017+ |

**Filtros exactos (sliders de cada portal) y su porqué:**

| Filtro | Dónde se pone | Valor directo URL | Por qué |
|---|---|---|---|
| Marca + Modelo | coches.net: Renault → Renault Megane gasolina<br>mobile.de: busca la marca a mano (ID sin verificar) | — | Marca y modelo exactos: es el filtro raíz; sin él todo lo demás no sirve. |
| Año desde 2016 | coches.net: «Año · desde» = 2016<br>mobile.de: «Erstzulassung ab» = 2016 | — | 2016+ = plataforma Megane IV (la del estudio); el III es otro coche y otro precio. |
| Precio desde 8.000 € (DE) | mobile.de: «Preis ab» = 8.000 € | — | Suelo verificado del estudio DE: por debajo suele haber siniestro, tuning o kilometraje loco. |
| Precio desde 8.200 € (ES) | coches.net: «Precio · desde» = 8.200 € | — | Suelo verificado del estudio ES: mismo criterio, para comparar apples con apples. |
| Combustible: Gasolina / Benzin | coches.net: «Combustible»<br>mobile.de: «Kraftstoff» | — | El estudio midió solo este combustible: mezclar diésel desplaza las medianas. |

**Cómo está el mercado (datos del mapa, tal cual):**

| Suelo DE | Suelo ES | Mediana DE | Mediana ES | Oferta DE | Oferta ES | Hueco | Hueco neto | Confianza |
|---|---|---|---|---|---|---|---|---|
| 8.000 € | 8.200 € | 12.000 € | 12.550 € | 947 | 383 | +4.4% | -7.4% | 3/5 |

Banda del estudio: ES y DE 8.000-17.000 EUR · Refrescar antes de: 2026-09-14

⚠️ **Trampa:** Mobile.de sin ID de marca verificado: busca 'Renault' → 'Megane' a mano.

<details><summary>Nota del estudio</summary>

Hueco bruto 4,4%, muy por debajo del umbral de 12% que exige el tramo 8-14k. Neto -7,4%: comprar en Espana.

</details>

