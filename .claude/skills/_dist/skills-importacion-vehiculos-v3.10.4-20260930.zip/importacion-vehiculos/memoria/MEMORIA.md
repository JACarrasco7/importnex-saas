# Memoria del skill `importacion-vehiculos`

> **Índice central de memoria del skill.** Claude debe leer este archivo al inicio de cada conversación sobre el skill. Se complementa con `.claude/memoria/` del proyecto JJImportMotors (preferencias, errores, decisiones).

---

## 📂 Estructura de la memoria del skill

| Archivo | Qué guarda | Cuándo consultar |
|---|---|---|
| **`MEMORIA.md`** (este) | Índice | SIEMPRE al inicio |
| `modelos-medidos.md` | Histórico de modelos investigados (cache) | Al retomar un modelo ya medido (PASO 0) |
| `encargos.md` | Registro central de encargos (cliente→flujo→entregables→resultado) | Al recibir cualquier encargo (PASO 0) · Auditoría de cierre |
| `filtros-portales.md` | Filtros/URLs verificados por portal (qué aplica por URL vs clic) | Al construir el plan de fase / asesor de filtros |
| `vendedores-confianza.md` | Dealers que responden bien | Antes de negociar |
| `trampas-encontradas.md` | Trampas detectadas en portales | Antes de cada navegación |
| `mejoras-aplicadas.md` | Cambios y mejoras del skill | Al planificar cambios |
| `retrospectiva.md` | Retrospectivas de sesión + plantilla de CIERRE | Al cerrar conversación / auditoría de cierre |
| `marketing-resultados.md` | Qué ángulo/gancho funcionó por coche y canal | Al elegir ángulo (07-marketing) · después de publicar |

---

## 🚦 Protocolo de uso

### Al INICIO de cada conversación:
1. Lee este `MEMORIA.md`
2. Lee `trampas-encontradas.md` (NO repetir errores)
3. Lee `modelos-medidos.md` + `encargos.md` (saber qué ya está hecho → **PASO 0 cache**, ver `../SKILL.md` §ARRANQUE)
4. Lee `mejoras-aplicadas.md` (respetar lo que funciona)
5. **3bis:** si el encargo es de mercado → cruzar con `indice.json` (Desktop, regla <3 semanas) y `datos_mercado.json`

### Durante la conversación:
- Si descubres una trampa nueva → añádela a `trampas-encontradas.md`
- Si mides un modelo nuevo → añádelo a `modelos-medidos.md` (12 campos, con `refrescar_antes_de`)
- Si cierras/abortas un encargo → regístralo en `encargos.md`
- Si verificas un filtro/URL nuevo en un portal → añádelo a `filtros-portales.md` (fecha + parámetro)
- Si un vendedor responde bien/mal → anótalo en `vendedores-confianza.md`
- Si mejoras el skill → documéntalo en `mejoras-aplicadas.md`
- Si una campaña de marketing ya tiene resultado (contactos, días al 1er contacto) → anótalo en `marketing-resultados.md`

### Al FINALIZAR:
- **Auditoría de cierre** (ver `../SKILL.md` §AUDITORÍA DE CIERRE): volcar las 5 dimensiones a `retrospectiva.md` (plantilla CIERRE)
- Verifica que los 9 archivos de memoria estén actualizados
- Si hay aprendizajes grandes → añádelos también a `.claude/memoria/decisiones.md` del proyecto

---

## 🧠 Tres tipos de memoria (recordatorio)

### 1. Corto plazo (sesión)
- **Qué:** Estado temporal de la conversación
- **Dónde:** `.claude/memoria/memoria-corto.md` del proyecto

### 2. Medio plazo (2-3 semanas)
- **Qué:** Datos de mercado, precios, comparables
- **Dónde:** `informes/datos/<marca>/<modelo>/mercado_<fecha>.json`

### 3. Largo plazo (permanente)
- **Qué:** Patrones, trampas, vendedores, mejoras
- **Dónde:** `memoria/*.md` (en este skill) + `.claude/memoria/*.md` (proyecto)

---

## 📊 Métricas del skill (acumuladas)

| Métrica | Valor |
|---|---|
| Versión actual | 3.9.3 |
| Fecha de release | 2026-09-12 |

---

## 📋 CASCADA DE INFORMES (12-ago-2026) — regla clave de comportamiento

Los informes NO salen todos a la vez. Es **en cascada** con checkpoint entre fases:

```
ENCARGO (Flujo B) → 📋 INFORME MODELO + top 5 con ENLACES → CP1 (¿Fase 2 o eliges?)
   │
   └─ ELIGES UNO → FLUJO A → 📋 INFORME UNIDAD (15 sec) → CP3 (veredicto)
        │
        └─ 🟢/🔵 → 📄 DOSSIER CLIENTE + 📦 ZIP Laravel
```

- **NUNCA** saltar del resumen informal al "¿evalúo el candidato X?" sin entregar INFORME MODELO + enlaces + CP1.
- El usuario decide qué candidato profundizar (Flujo A), no Claude.
- Folleto publicidad / ficha → los genera **Laravel** (no Claude), cuando el coche está en inventario.
- Plantilla INFORME MODELO en `../SKILL.md` §INFORME TIPO MODELO.

## 🌍 ORIGEN DE vs ES + negocio (12-ago-2026)

- **Negocio:** NO compramos stock. Solo ofertamos el servicio (honorarios). El cliente compra el coche.
- **Ámbito:** importación desde Alemania + servicios de búsqueda y gestión dentro de España.
- **Origen:** si no se especifica → buscar en AMBOS mercados y comparar dónde sale mejor. DE = con costes de importación; ES = sin ellos. Ver `../04-negocio/costes.md` §Origen.

## 📊 Métricas del skill (detalle)

| Métrica | Valor |
|---|---|
| Fuentes integradas | 7 portales |
| Cobertura | 100% (DE + ES) |
| Trampas documentadas | 8 (4 confirmadas, 4 potenciales) |
| Modelos medidos | 4 (Astra OPC ×2, Tiguan, Golf GTI) |
| Coches evaluados | 7 |
| Encargos registrados | 9 (8 cerrados + 1 abortado) |
| Tests PHP pasando | 4/4 |

---

## 🔗 Memoria relacionada

**Memoria del proyecto JJImportMotors** (en `c:\Users\jacar\Desktop\JJImportMotors\.claude\`):
- `MEMORIA.md` — índice del proyecto
- `memoria/preferencias.md` — cómo trabaja el usuario
- `memoria/decisiones.md` — por qué se hicieron las cosas
- `memoria/errores-pasados.md` — errores NO repetir
- `memoria/memoria-larga.md` — patrones generales

---

## 🗓️ Última actualización

- **2026-09-12:** v3.9.2 — Dos tandas de trabajo que se habían preparado en sesión pero nunca
  llegaron a copiarse al repo real (`.claude/` rechaza escrituras del puente remoto: hace
  falta el `.bat` de sincronización). Ahora sí están aplicadas: precio del cliente en
  horquilla (nunca cifra cerrada) con desglose `[GASTO]`/`[FC_GASTO]`, fix del 21% de IVA
  fantasma, rediseño móvil del dossier, y el fix de `ingestarPortalesV2()` para que los 4
  canales de portal dejen de recibir el mismo texto. **Aprendizaje operativo:** cuando un
  cambio queda "preparado" pero no se confirma que el `.bat` se ejecutó, la sesión siguiente
  no puede asumir que está en producción — hay que releer el fichero real del repo antes de
  dar nada por hecho, no fiarse del historial de la conversación. **Aprendizaje técnico:**
  cuando la skill y el panel mantienen dos modelos de costes en paralelo, divergen sin avisar
  (el 21% de IVA vivía solo en `PrecioClienteCalculator.php`, nunca en `04-negocio/costes.md`)
  — una sola fuente, siempre. Mismo patrón en marketing: la skill llevaba desde el 05-sep
  generando `PT_TITULO_A/B`/`FBMP_*` diferenciados que el panel nunca leía (seguía en
  vocabulario v1) — de ahí que 4 canales de portal recibieran el mismo texto durante más de
  una semana sin que nadie lo detectara hasta que el usuario lo señaló directamente.
  **Cuarto hallazgo (revisión de cierre, mismo día):** el mismo patrón exacto una tercera vez —
  `Marketing.vue` tenía un comentario "B1 auditoría 09-sep-2026" que daba por verificado que
  `config/marketing_limits.php` existía y que el controlador enviaba `props.limits`; ninguna de
  las dos cosas era cierta, así que el contador de caracteres del editor llevaba SIEMPRE
  mostrando la guía genérica para los 6 canales. Se corrigió en la misma tanda. **Regla que hay
  que empezar a aplicar de forma sistemática:** un comentario en el código que dice "ya
  verificado" o "ya existe" no es evidencia — hay que abrir el fichero que dice referenciar
  antes de darlo por bueno, cada vez, no solo cuando el usuario pregunta si queda algo
  pendiente.
- **2026-09-09:** v3.8.0 — Cadena empaquetar → ZIP → panel cerrada (ficha-cliente.json real, vocabulario de marketing unificado v1.5/v2, parsers alineados con `App\Support\Esqueleto`). Ficha del cliente pública (A22b/A31) fusionada y en producción (`FiltroPublico`, ruta de fotos, ficha técnica con fallback). Este índice referencia ya los 9 archivos de memoria (se añadió `marketing-resultados.md`, que faltaba).
- **2026-08-16:** v3.1.0 — Reorganización física completa (carpetas 01-06), `encargos.md` + `filtros-portales.md` creados, `modelos-medidos.md` ampliado a 12 campos, este índice con 8 archivos + PASO 0 cache.

---

## 🆕 Cambios v3.9.3 (12-sep-2026) que afectan a futuras sesiones

La skill v3.9.2 que había en este directorio quedó **desincronizada** con el repo real.
Esta versión 3.9.3 refleja el estado actual de producción.

### Para Claude al evaluar/coches:

- **Caption del precio:** es "+ gastos gestión de compra" (NO "+ gastos de gestión de compra
  e importación" como decía el commit v3.9.0 inicial). Es el canónico v3.9.0/v3.9.2.

- **Dossier público reorganizado:** galería en posición 2 (justo tras la valoración), FAQ y
  CTA Final en partials Blade separados (`resources/views/public/dossier/partials/`).

- **KPI Origen del dossier:** SIEMPRE debe aparecer (el bug del 12-sep que lo dejaba en
  null ya está corregido). Sale de `car.pais_origen` (NO `origin_country` — esa columna
  NO EXISTE).

- **fuel:** en BD viene del scraping en inglés (Gasoline, Diesel, Hybrid). El Blade lo
  traduce al español. Si Claude lo lee directamente, también verá "Gasoline" en la BD.

### Para Claude al generar ZIPs:

- El panel admin `/cars/{id}` está troceado en 11 partials Vue. NO toques nada del panel —
  solo entrega el ZIP y Laravel lo pinta.

- Los bloques nuevos `[GASTO]` y `[FC_GASTO]` los emite `empaquetar.py::gastos_cliente()` y los
  lee `PrecioClienteCalculator::desgloseDeSkill()` con prioridad sobre la estimación propia.
  Si Claude escribe gastos en la ficha-cliente, formato: `[{concepto: ..., importe: ...}]`.

### Tests PHP del proyecto Laravel: 660 passing (12-sep-2026)

### Commits en master relevantes para esta versión:

```
07596f6  test(precio+dossier): actualizar al contrato v3.9.2
cb5e01a  feat(marketing+precio): skill v3.9.2 + horquilla + canales + guía
a1908e5  fix(dossier): origen real, fuel en espanol, galeria arriba y titulos
ea9b49b  fix(dossier): margin-top en sections para evitar margin-collapse
4a00f95  fix(dossier): separar FAQ y CTA + spacing entre secciones
a586d20  chore(cars): eliminar handlePhotoFiles muerto
a4d946c  refactor(cars): continuar troceando Show.vue (889 a 717 lineas)
1c1c724  refactor(cars): trocear Show.vue (1548→889 lineas) con Partials/
```
